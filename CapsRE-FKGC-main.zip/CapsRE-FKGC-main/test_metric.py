

if __name__ == '__main__':
    predict_by_split()