import math

from torch import device

from atten_mech import dot_attention
from embedding import *
from hyper_embedding import *
from collections import OrderedDict
import torch
import json
import numpy as np
import torch.nn.init as init
import torch.nn.functional as F
from torch.autograd import Variable



class RelationMetaLearner(nn.Module):
    def __init__(self, few, embed_size=50, num_hidden1=500, num_hidden2=100, out_size=50, dropout_p=0.5):
        super(RelationMetaLearner, self).__init__()
        self.embed_size = embed_size
        self.few = few
        self.out_size = out_size
        self.rel_fc1 = nn.Sequential(OrderedDict([
            ('fc', nn.Linear(2 * embed_size, num_hidden1)),
            ('bn', nn.BatchNorm1d(few)),
            ('relu', nn.LeakyReLU()),
            ('drop', nn.Dropout(p=dropout_p)),
        ]))
        self.rel_fc2 = nn.Sequential(OrderedDict([
            ('fc', nn.Linear(num_hidden1, num_hidden2)),
            ('bn', nn.BatchNorm1d(few)),
            ('relu', nn.LeakyReLU()),
            ('drop', nn.Dropout(p=dropout_p)),
        ]))
        self.rel_fc3 = nn.Sequential(OrderedDict([
            ('fc', nn.Linear(num_hidden2, out_size)),
            ('bn', nn.BatchNorm1d(few)),
        ]))
        nn.init.xavier_normal_(self.rel_fc1.fc.weight)
        nn.init.xavier_normal_(self.rel_fc2.fc.weight)
        nn.init.xavier_normal_(self.rel_fc3.fc.weight)

    def forward(self, inputs):
        size = inputs.shape
        # print("inputs-----", inputs.shape)
        x = inputs.contiguous().view(size[0], size[1], -1)
        x = self.rel_fc1(x)
        # print("x1-----", x.shape)
        x = self.rel_fc2(x)
        # print("x2-----", x.shape)
        # x = self.rel_fc3(x)
        # print("x3-----", x.shape)
        # x = torch.mean(x, 1)
        # print("x_mean-----", x.shape)
        # print("x_view-----",

        return x.view(size[0], self.few, 2, self.out_size)


# 双线性层
class RelationInitLearner(nn.Module):
    def __init__(self, few, embed_size=100, num_hidden1=500, num_hidden2=50, out_size=100, dropout_p=0.5):
        super(RelationInitLearner, self).__init__()
        self.embed_size = embed_size
        self.few = few
        self.out_size = out_size
        self.rel_fc1 = nn.Sequential(OrderedDict([
            ('fc', nn.Linear(2 * embed_size, num_hidden1))
        ]))
        self.rel_fc2 = nn.Sequential(OrderedDict([
            ('fc', nn.Linear(num_hidden1, num_hidden2)),
            ('relu', nn.LeakyReLU())
        ]))
        #
        # nn.init.xavier_normal_(self.rel_fc1.fc.weight)
        # nn.init.xavier_normal_(self.rel_fc2.fc.weight)

    def forward(self, inputs):
        size = inputs.shape
        # print("inputs-----", inputs.shape) # [16, 5, 2, 100]
        x = inputs.contiguous().view(size[0], size[1], -1)
        # print("x0-----",x.shape)  # [16, 5, 200]
        x = self.rel_fc1(x)
        # print("x1-----", x.shape)  # [16, 5, 500]
        x = self.rel_fc2(x)

        return x.view(size[0], self.few, 2, self.out_size)


# 学习关系初表示
class LSTM_attn(nn.Module):
    def __init__(self, embed_size=50, n_hidden=200, out_size=100, layers=1, dropout=0.5):
        super(LSTM_attn, self).__init__()
        self.embed_size = embed_size
        self.n_hidden = n_hidden
        self.out_size = out_size
        self.layers = layers
        self.dropout = dropout
        self.lstm = nn.LSTM(self.embed_size * 2, self.n_hidden, self.layers, bidirectional=True, dropout=self.dropout)
        # self.gru = nn.GRU(self.embed_size*2, self.n_hidden, self.layers, bidirectional=True)
        self.out = nn.Linear(self.n_hidden * 2 * self.layers, self.out_size)
        ##add
        # Conv2d layer
        # self.conv = nn.Conv2d(1, 256, 3)
        # self.conv = nn.Conv1d(in_channels=5, out_channels=256, kernel_size=1)

        self.conv = nn.Conv2d(1, 256, (3, 200))

        # (k,config.hidden_size)  n-gram,embedding维度

        self.relu = nn.ReLU(inplace=True)

        # Primary capsule
        self.primary_caps = PrimaryCaps(num_conv_units=32,
                                        in_channels=1,
                                        out_channels=8,
                                        kernel_size=(3, 200),
                                        stride=1)

        # Digit capsule
        self.digit_caps = DigitCaps(in_dim=8,
                                    in_caps=96,
                                    num_caps=5,
                                    dim_caps=200,
                                    num_routing=3)



    def attention_net(self, lstm_output, final_state):
        hidden = final_state.view(-1, self.n_hidden * 2, self.layers)
        attn_weight = torch.bmm(lstm_output, hidden).squeeze(2).cuda()
        # batchnorm = nn.BatchNorm1d(5, affine=False).cuda()
        # attn_weight = batchnorm(attn_weight)
        soft_attn_weight = F.softmax(attn_weight, 1)
        context = torch.bmm(lstm_output.transpose(1, 2), soft_attn_weight)
        context = context.view(-1, self.n_hidden * 2 * self.layers)
        return context

    def forward(self, inputs):
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        size = inputs.shape #(16,5,2,100)
        inputs = inputs.contiguous().view(size[0], size[1], -1) #(16,5,200)
        input = inputs.permute(1, 0, 2)
        hidden_state = Variable(torch.zeros(self.layers * 2, size[0], self.n_hidden)).cuda()
        cell_state = Variable(torch.zeros(self.layers * 2, size[0], self.n_hidden)).cuda()
        output, (final_hidden_state, final_cell_state) = self.lstm(input, (hidden_state, cell_state))  # LSTM
        output = output.permute(1, 0, 2)  #(16,5,200) (16,5,1200)  （batch，shot，dim）
        output = output.unsqueeze(1)  # （16，1，5，200）add  （16，1，5，1200）

        # add
        # caps_out = self.relu(self.conv(output))   # (16,256,1200)  #(16,256,3,1)
        caps_out = self.primary_caps(output)  # (16,96,8)
        caps_out = self.digit_caps(caps_out)  # （16，5，200）   (200,5,5,200,3) (16,5,1200)
        # caps_out = caps_out.view()
        # caps_out = caps_out.squeeze(1)
        # attn_output = self.attention_net(caps_out, final_hidden_state)    #(16,2400)   # change log
        attn_output = self.attention_net(caps_out, final_cell_state)  # (16,400)   # change log

        outputs = self.out(attn_output) # (16,50)
        # outputs = self.out(caps_out)

        # outputs = self.out(caps_out)
        # logits = torch.norm(caps_out, dim=-1)
        # outputs = torch.eye(5).to(device).index_select(dim=0, index=torch.argmax(logits, dim=1))  #(16,100)
        return outputs.view(size[0], 1, 1, self.out_size)
        # return outputs

class EmbeddingLearner(nn.Module):
    def __init__(self):
        super(EmbeddingLearner, self).__init__()

    def forward(self, h, t, r, pos_num, norm):
        norm = norm[:, :1, :, :]  # revise
        h = h - torch.sum(h * norm, -1, True) * norm
        t = t - torch.sum(t * norm, -1, True) * norm
        score = -torch.norm(h + r - t, 2, -1).squeeze(2)  # 1024，10
        p_score = score[:, :pos_num]  # 1024，5
        n_score = score[:, pos_num:]  # 1024，5
        return p_score, n_score



def squash(x, dim=-1):

    squared_norm = (x ** 2).sum(dim=dim, keepdim=True)
    scale = squared_norm / (1 + squared_norm)
    return scale * x / (squared_norm.sqrt() + 1e-8)


class PrimaryCaps(nn.Module):
    """Primary capsule layer."""

    def __init__(self, num_conv_units, in_channels, out_channels, kernel_size, stride):
        super(PrimaryCaps, self).__init__()

        # Each conv unit stands for a single capsule.
        self.conv = nn.Conv2d(in_channels=in_channels,
                              out_channels=out_channels * num_conv_units,
                              kernel_size=kernel_size,
                              stride=stride)
        self.out_channels = out_channels

    def forward(self, x):
        # Shape of x: (batch_size, in_channels, height, weight)
        # Shape of out: num_capsules * (batch_size, out_channels, height, weight)
        out = self.conv(x)  # (16,1000,1,1) (16,256,3,1)
        # Flatten out: (batch_size, num_capsules * height * weight, out_channels)
        batch_size = out.shape[0]
        return squash(out.contiguous().view(batch_size, -1, self.out_channels), dim=-1)



class DigitCaps(nn.Module):
    """Digit capsule layer."""

    #
    def __init__(self, in_dim, in_caps, num_caps, dim_caps, num_routing):
        """
        Initialize the layer.

        """
        super(DigitCaps, self).__init__()
        self.in_dim = in_dim
        self.in_caps = in_caps
        self.num_caps = num_caps
        self.dim_caps = dim_caps
        self.num_routing = num_routing
        self.device = device
        self.W = nn.Parameter(0.01 * torch.randn(1, num_caps, in_caps, dim_caps, in_dim),
                              requires_grad=True)

    def forward(self, x):
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        batch_size = x.size(0)
        # (batch_size, in_caps, in_dim) -> (batch_size, 1, in_caps, in_dim, 1)
        x = x.unsqueeze(1).unsqueeze(4)
        #
        # W @ x =
        # (1, num_caps, in_caps, dim_caps, in_dim) @ (batch_size, 1, in_caps, in_dim, 1) =
        # (batch_size, num_caps, in_caps, dim_caps, 1)
        u_hat = torch.matmul(self.W, x)
        # (batch_size, num_caps, in_caps, dim_caps)
        u_hat = u_hat.squeeze(-1)
        # detach u_hat during routing iterations to prevent gradients from flowing
        temp_u_hat = u_hat.detach() #（16，5，96，200）

        b = torch.zeros(batch_size, self.num_caps, self.in_caps, 1).to(device)  # （16，5，96，1）设置初始权重

        for route_iter in range(self.num_routing - 1):
            # (batch_size, num_caps, in_caps, 1) -> Softmax along num_caps
            c = b.softmax(dim=1)

            # element-wise multiplication
            # (batch_size, num_caps, in_caps, 1) * (batch_size, in_caps, num_caps, dim_caps) ->
            # (batch_size, num_caps, in_caps, dim_caps) sum across in_caps ->
            # (batch_size, num_caps, dim_caps)
            s = (c * temp_u_hat).sum(dim=2)
            # apply "squashing" non-linearity along dim_caps
            v = squash(s)
            # dot product agreement between the current output vj and the prediction uj|i
            # (batch_size, num_caps, in_caps, dim_caps) @ (batch_size, num_caps, dim_caps, 1)
            # -> (batch_size, num_caps, in_caps, 1)
            uv = torch.matmul(temp_u_hat, v.unsqueeze(-1)) # （16，5，96，1）
            b += uv

        # last iteration is done on the original u_hat, without the routing weights update
        c = b.softmax(dim=1)
        s = (c * u_hat).sum(dim=2)
        # apply "squashing" non-linearity along dim_caps
        v = squash(s)

        return v


def save_grad(grad):
    global grad_norm
    grad_norm = grad



class MetaR(nn.Module):
    def __init__(self, dataset, parameter, num_symbols, embed=None):
        super(MetaR, self).__init__()
        self.device = parameter['device']
        self.beta = parameter['beta']
        self.dropout_p = parameter['dropout_p']
        self.embed_dim = parameter['embed_dim']
        self.margin = parameter['margin']
        self.abla = parameter['ablation']
        self.rel2id = dataset['rel2id']
        self.num_rel = len(self.rel2id)
        self.embedding = Embedding(dataset, parameter)
        self.h_embedding = H_Embedding(dataset, parameter)
        self.few = parameter['few']
        self.dropout = nn.Dropout(0.5)
        self.symbol_emb = nn.Embedding(num_symbols + 1, self.embed_dim, padding_idx=num_symbols)
        self.num_hidden1 = 500
        self.num_hidden2 = 200
        self.lstm_dim = parameter['lstm_hiddendim']
        self.lstm_layer = parameter['lstm_layers']

        self.symbol_emb.weight.data.copy_(torch.from_numpy(embed))

        self.h_emb = nn.Embedding(self.num_rel, self.embed_dim)
        init.xavier_uniform_(self.h_emb.weight)

        self.gcn_w = nn.Linear(2 * self.embed_dim, self.embed_dim)  # change log
        self.gcn_b = nn.Parameter(torch.FloatTensor(self.embed_dim))  # change log
        self.attn_w = nn.Linear(self.embed_dim, 1)

        # self.attn_w = nn.Linear(self.embed_dim, 50)

        self.gate_w = nn.Linear(self.embed_dim, 1)
        self.gate_b = nn.Parameter(torch.FloatTensor(1))

        init.xavier_normal_(self.gcn_w.weight)  # change log
        init.constant_(self.gcn_b, 0)  # change log
        init.xavier_normal_(self.attn_w.weight)

        self.symbol_emb.weight.requires_grad = False

        self.h_norm = None

        if parameter['dataset'] == 'Wiki-One':
            self.relation_learner = LSTM_attn(embed_size=50, n_hidden=100, out_size=50, layers=2, dropout=0.5)
        elif parameter['dataset'] == 'NELL-One':
            self.relation_learner = LSTM_attn(embed_size=100, n_hidden=self.lstm_dim, out_size=100,
                                              layers=self.lstm_layer, dropout=self.dropout_p)
        self.embedding_learner = EmbeddingLearner()
        self.loss_func = nn.MarginRankingLoss(self.margin)
        # ttt
        self.criterion = nn.CrossEntropyLoss().cuda()

        self.rel_q_sharing = dict()
        self.norm_q_sharing = dict()

        # # add
        # self.relation_meta_learner = RelationMetaLearner(few=self.few, embed_size=100, num_hidden1=500, num_hidden2=200,
        #                                                  out_size=100, dropout_p=0.5)
        # to wiki
        self.relation_meta_learner = RelationMetaLearner(few=self.few, embed_size=50, num_hidden1=500, num_hidden2=100,
                                                         out_size=50, dropout_p=0.5)
        # RelationInitLearner
        # self.relation_meta_learner = RelationInitLearner(few=self.few, embed_size=100, num_hidden1=500, num_hidden2=200, out_size=100, dropout_p=0.5)
        # self.Wv = nn.Parameter(torch.randn(16, 100, 1))  # change log
        # Wv = torch.randn(16, 100, self.embed_dim)
        # self.W = nn.Parameter(torch.randn(16, 100, 1))

        # self.Wk = nn.Linear(self.embed_dim, 1)

        #to wiki
        self.Wk = nn.Linear(2*self.embed_dim, 1)

        self.Wv = nn.Linear(self.embed_dim, 1)
        nn.init.xavier_uniform_(self.Wv.weight)
        nn.init.xavier_uniform_(self.Wk.weight)

        self.isCompeteBatch = True


    def neighbor_encoder(self, connections, num_neighbors, iseval):
        '''
        邻居
        '''
        num_neighbors = num_neighbors.unsqueeze(1)
        entity_self = connections[:, 0, 0].squeeze(-1)
        relations = connections[:, :, 1].squeeze(-1)
        entities = connections[:, :, 2].squeeze(-1)
        rel_embeds = self.dropout(self.symbol_emb(relations))  # (batch, 200, embed_dim)
        ent_embeds = self.dropout(self.symbol_emb(entities))  # (batch, 200, embed_dim)
        entself_embeds = self.dropout(self.symbol_emb(entity_self))
        if not iseval:
            entself_embeds = entself_embeds.squeeze(1)
        concat_embeds = torch.cat((rel_embeds, ent_embeds), dim=-1)  # (batch, 200, 2*embed_dim)
        # print("concat_embeds",concat_embeds.shape)
        # out = F.leaky_relu(concat_embeds)  # out gcn former change log
        # out = self.gcn_w(out) + self.gcn_b  # out gcn former change log

        out = self.gcn_w(concat_embeds) + self.gcn_b
        out = F.leaky_relu(out)

        attn_out = self.attn_w(out)


        K = self.Wk(out.transpose(1, 2))


        # alpha_score = torch.bmm(attn_out, K.transpose(1, 2))
        alpha_score = torch.bmm(out, K)

        # alpha_score /= math.sqrt(self.embed_dim)

        alpha_score = F.softmax(alpha_score, dim=1)

        V = self.Wv(out)
        # out_attn = torch.bmm(alpha_score, V)


        out_attn = torch.bmm(out.transpose(1, 2), alpha_score) #(16,50,1)



        out_attn = out_attn.squeeze(2)  # ([16, 100])
        # print("out_attn\n", out_attn.shape)
        # print("gate_b",self.gate_b.shape)


        gate_tmp = self.gate_w(out_attn) + self.gate_b
        gate = torch.sigmoid(gate_tmp)
        out_neigh = torch.mul(out_attn, gate)
        out_neighbor = out_neigh + torch.mul(entself_embeds, 1.0 - gate)

        return out_neighbor

    def split_concat(self, positive, negative):
        pos_neg_e1 = torch.cat([positive[:, :, 0, :],
                                negative[:, :, 0, :]], 1).unsqueeze(2)
        pos_neg_e2 = torch.cat([positive[:, :, 1, :],
                                negative[:, :, 1, :]], 1).unsqueeze(2)
        return pos_neg_e1, pos_neg_e2

    def forward(self, task, iseval=False, curr_rel='', support_meta=None, istest=False):

        # transfer task string into embedding
        # support(1024,5,2,100)          # query(1024,3,2,100)
        support, support_negative, query, negative = [self.embedding(t) for t in task]
        norm_vector = self.h_embedding(task[0])  # (1024,5,1,100)
        few = support.shape[1]
        num_sn = support_negative.shape[1]
        num_q = query.shape[1]  #
        num_n = negative.shape[1]

        support_left_connections, support_left_degrees, support_right_connections, support_right_degrees = support_meta[0]
        support_left = self.neighbor_encoder(support_left_connections, support_left_degrees, iseval)
        support_right = self.neighbor_encoder(support_right_connections, support_right_degrees, iseval)
        support_few = torch.cat((support_left, support_right), dim=-1)
        support_few = support_few.view(support_few.shape[0], 2, self.embed_dim)

        for i in range(self.few - 1):
            support_left_connections, support_left_degrees, support_right_connections, support_right_degrees = \
                support_meta[i + 1]
            support_left = self.neighbor_encoder(support_left_connections, support_left_degrees, iseval)
            support_right = self.neighbor_encoder(support_right_connections, support_right_degrees, iseval)
            support_pair = torch.cat((support_left, support_right), dim=-1)  # tanh
            support_pair = support_pair.view(support_pair.shape[0], 2, self.embed_dim)
            support_few = torch.cat((support_few, support_pair), dim=1)
        support_few = support_few.view(support_few.shape[0], self.few, 2, self.embed_dim)
        # print("support_few--------------",support_few.shape) #[16, 5, 2, 100]

        # add
        rel = self.relation_meta_learner(support_few)

        rel = self.relation_learner(rel)


        # rel.requires_grad = True  # add
        rel.retain_grad()  #

        rel_s = rel.expand(-1, few + num_sn, -1, -1)  # （1024，10，1，100）
        if iseval and curr_rel != '' and curr_rel in self.rel_q_sharing.keys():
            rel_q = self.rel_q_sharing[curr_rel]

        else:
            if not self.abla:
                # split on e1/e2 and concat on pos/neg
                sup_neg_e1, sup_neg_e2 = self.split_concat(support, support_negative)

                p_score, n_score = self.embedding_learner(sup_neg_e1, sup_neg_e2, rel_s, few,
                                                          norm_vector)  # revise norm_vector

                y = torch.Tensor([1]).to(self.device)
                self.zero_grad()
                # normalization = 0.0001 * (torch.sum(norm_vector**2) + torch.sum(rel_s**2))

                loss = self.loss_func(p_score, n_score, y)
                # print(p_score.shape)
                # print(n_score.shape)
                # print(y.shape)

                # loss = self.loss_func(p_score, n_score, y) + normalization
                loss.backward(retain_graph=True)
                grad_meta = rel.grad
                rel_q = rel - self.beta * grad_meta
                norm_q = norm_vector - self.beta * grad_meta
            else:
                rel_q = rel
                norm_q = norm_vector

            self.rel_q_sharing[curr_rel] = rel_q
            self.h_norm = norm_vector.mean(0)  # （5，1，100）
            self.h_norm = self.h_norm.unsqueeze(0)

        rel_q = rel_q.expand(-1, num_q + num_n, -1, -1)


        que_neg_e1, que_neg_e2 = self.split_concat(query, negative)  # [bs, nq+nn, 1, es]
        if iseval:
            norm_q = self.h_norm
        p_score, n_score = self.embedding_learner(que_neg_e1, que_neg_e2, rel_q, num_q, norm_q)

        return p_score, n_score  # （1024，5）
