

import json

with open('./data/UMLS/entities.json') as f:
    result = json.loads(f)
    i = 0
    # for key, value in result.items():
    #     i +=1
    print(i)