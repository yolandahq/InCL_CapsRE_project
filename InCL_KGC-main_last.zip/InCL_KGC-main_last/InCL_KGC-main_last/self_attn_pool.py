# import torch
# from torch import nn
# from utils import masked_softmax
#
# device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
#
# class SelfAttnAggregator(nn.Module):
#
#     # def __init__(self, output_dim,
#     #              attn_vector=None) -> None:
#     #     super(SelfAttnAggregator, self).__init__()
#     #
#     #     self.output_dim = output_dim
#     #     self.attn_vector = None
#     #     if attn_vector:
#     #         self.attn_vector = attn_vector
#     #     else:
#     #         self.attn_vector = nn.Linear(
#     #             self.output_dim,
#     #             1
#     #         )
#     def __init__(self, output_dim,
#                  attn_vector=None) -> None:
#         super(SelfAttnAggregator, self).__init__()
#
#         self.output_dim = output_dim
#         self.attn_vector = nn.Linear(768, 1)
#         self.activation = nn.Tanh()
#     def forward(self, input_tensors: torch.Tensor, mask: torch.Tensor):
#         self_attention_logits = self.attn_vector(input_tensors).to(device)
#         self_attention_logits = self.activation(self_attention_logits).to(device)
#         self_attention_logits.squeeze(2).to(device)
#         # 获取注意力权重
#         self_weights = masked_softmax(self_attention_logits, mask).to(device)
#         # 加权求和
#         input_self_attn_pooled = sum(input_tensors * self_weights, 1).to(device)
#
#         return input_self_attn_pooled
