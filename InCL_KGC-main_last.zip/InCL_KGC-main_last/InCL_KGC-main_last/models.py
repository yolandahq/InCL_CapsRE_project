from abc import ABC
from copy import deepcopy

import torch
import torch.nn as nn
import numpy as np
import time
from operator import length_hint

from dataclasses import dataclass
from transformers import AutoModel, AutoConfig

from triplet_mask import construct_mask
from attn_mech import dot_attention
import torch.nn.functional as F

def build_model(args) -> nn.Module:
    return CustomBertModel(args)


@dataclass
class ModelOutput:
    logits: torch.tensor
    labels: torch.tensor
    inv_t: torch.tensor
    hr_vector: torch.tensor
    tail_vector: torch.tensor


class CustomBertModel(nn.Module, ABC):
    def __init__(self, args):
        super().__init__()
        self.args = args
        self.config = AutoConfig.from_pretrained(args.pretrained_model)
        self.log_inv_t = torch.nn.Parameter(torch.tensor(1.0 / args.t).log(), requires_grad=args.finetune_t)
        self.add_margin = args.additive_margin
        self.batch_size = args.batch_size
        self.pre_batch = args.pre_batch
        num_pre_batch_vectors = max(1, self.pre_batch) * self.batch_size
        random_vector = torch.randn(num_pre_batch_vectors, self.config.hidden_size)
        self.register_buffer("pre_batch_vectors",
                             nn.functional.normalize(random_vector, dim=1),
                             persistent=False)
        self.offset = 0
        self.pre_batch_exs = [None for _ in range(num_pre_batch_vectors)]
        ##
        self.K = args.K
        self.register_buffer("nei_tail_vector",
                             nn.functional.normalize(random_vector, dim=1),
                             persistent=False)
        ##
        self.hr_bert = AutoModel.from_pretrained(args.pretrained_model)
        self.tail_bert = deepcopy(self.hr_bert)

        ##
        self.poly_m = 16
        self.poly_code_embeddings = nn.Embedding(self.poly_m + 1, args.hidden_size)
        self.res_cnt = args.batch_size

        self.dropout = nn.Dropout(args.dropout)
        self.context_fc = nn.Linear(args.hidden_size, args.hidden_size)
        self.response_fc = nn.Linear(args.hidden_size, args.hidden_size)


    def _encode(self, encoder, token_ids, mask, token_type_ids):
        outputs = encoder(input_ids=token_ids,
                          attention_mask=mask,
                          token_type_ids=token_type_ids,
                          return_dict=True)

        last_hidden_state = outputs.last_hidden_state  # [bs, length, dim]
        # cls_output = last_hidden_state[:, 0, :]  # [bs,dim]
        # cls_output = _pool_output(self.args.pooling, cls_output, mask, last_hidden_state)  # [bs,dim]
        cls_output = last_hidden_state
        return cls_output

    def forward(self, hr_token_ids, hr_mask, hr_token_type_ids,
                tail_token_ids, tail_mask, tail_token_type_ids,
                head_token_ids, head_mask, head_token_type_ids,
                only_ent_embedding=False, **kwargs) -> dict:
        # res_cnt = tail_token_ids.shape

        ##-----------

        batch_size = hr_token_ids.shape[0]
        if only_ent_embedding:
            return self.predict_ent_embedding(tail_token_ids=tail_token_ids,
                                              tail_mask=tail_mask,
                                              tail_token_type_ids=tail_token_type_ids)
        ##hr_encoder
        hr_vector = self._encode(self.hr_bert,
                                 token_ids=hr_token_ids,
                                 mask=hr_mask,
                                 token_type_ids=hr_token_type_ids)
        poly_code_ids = torch.arange(self.poly_m, dtype=torch.long, device=hr_token_ids.device)  # [m]
        poly_code_ids += 1
        poly_code_ids = poly_code_ids.unsqueeze(0).expand(batch_size, self.poly_m)  # [bs,m]
        poly_codes = self.poly_code_embeddings(poly_code_ids)  # [bs, m, dim]
        hr_vector = dot_attention(poly_codes, hr_vector, hr_vector, hr_mask, self.dropout)  # [bs, m, dim]


        ## key_encoder
        tail_vector = self._encode(self.tail_bert,
                                   token_ids=tail_token_ids,
                                   mask=tail_mask,
                                   token_type_ids=tail_token_type_ids)
        # poly_code_ids = torch.zeros(self.batch_size * self.res_cnt, 1, dtype=torch.long, device=hr_token_ids.device)
        poly_code_ids = torch.zeros(batch_size, 1, dtype=torch.long, device=hr_token_ids.device) # [bs,1]
        poly_codes = self.poly_code_embeddings(poly_code_ids) # [bs, 1, dim]
        tail_vector = dot_attention(poly_codes, tail_vector, tail_vector, tail_mask, self.dropout)  # [bs, length, dim] 2,2,384
        # tail_vector = tail_vector.view(self.batch_size, self.res_cnt, -1)

        # head_encode
        head_vector = self._encode(self.tail_bert,
                                   token_ids=head_token_ids,
                                   mask=head_mask,
                                   token_type_ids=head_token_type_ids)
        last_hidden_state = head_vector
        head_vector = last_hidden_state[:, 0, :]
        head_vector = _pool_output(self.args.pooling, head_vector, head_mask, last_hidden_state)

        # attn激活
        hr_vector = self.context_fc(self.dropout(hr_vector))
        hr_vector = F.normalize(hr_vector, 2, -1)  # [bs, m, dim]
        tail_vector = self.response_fc(self.dropout(tail_vector))
        tail_vector = F.normalize(tail_vector, 2, -1)

        # final hr_vector
        hr_vector = dot_attention(tail_vector, hr_vector, hr_vector, None, self.dropout)
        hr_vector = F.normalize(hr_vector, 2, -1).squeeze(1)  # [bs, res_cnt, dim], res_cnt==bs when training
        tail_vector = tail_vector.squeeze(1)
        # DataParallel only support tensor/dict
        # print('hr_vector--------------------------------------------------',hr_vector.shape)
        return {'hr_vector': hr_vector,
                'tail_vector': tail_vector,
                'head_vector': head_vector}

    def compute_logits(self, output_dict: dict, batch_dict: dict) -> dict:
        hr_vector, tail_vector = output_dict['hr_vector'], output_dict['tail_vector']  # [2,16,768]
        batch_size = hr_vector.size(0)
        labels = torch.arange(batch_size).to(hr_vector.device)
        # print('output_dict--------------------------------------------------',output_dict.keys())
        # print('labels--------------------------------------------------',labels)

        logits = hr_vector.mm(tail_vector.t())
        # print('logits--------------------------------------------------',logits.shape)
        if self.training:
            logits -= torch.zeros(logits.size()).fill_diagonal_(self.add_margin).to(logits.device)
        logits *= self.log_inv_t.exp()

        triplet_mask = batch_dict.get('triplet_mask', None)
        # print('batch_dict--------------------------------------------------',batch_dict.keys())

        # print('batch_data--------------------------------------------------',batch_dict['batch_data'])
        if triplet_mask is not None:
            logits.masked_fill_(~triplet_mask, -1e4)


        if self.pre_batch > 0 and self.training:
            pre_batch_logits = self._compute_pre_batch_logits(hr_vector, tail_vector, batch_dict)
            # print('pre_batch_logits--------------------------------------------------',pre_batch_logits.shape)
            logits = torch.cat([logits, pre_batch_logits], dim=-1)


        if self.args.use_self_negative and self.training:
            head_vector = output_dict['head_vector']
            self_neg_logits = torch.sum(hr_vector * head_vector, dim=1) * self.log_inv_t.exp()
            self_negative_mask = batch_dict['self_negative_mask']
            self_neg_logits.masked_fill_(~self_negative_mask, -1e4)
            logits = torch.cat([logits, self_neg_logits.unsqueeze(1)], dim=-1)


        # 近邻采样
        if self.K > 0 and self.training:
            # print('logits近邻采样--------------------------------------------------')
            tail_vector = output_dict['tail_vector']
            # print('近邻采样tail_vector--------------------------------------------------',tail_vector.shape)
            nei_tail_vector = self._nearest_neighbor_sampling(tail_vector, self.K)
            # print('nei_tail_vector--------------------------------------------------',nei_tail_vector.shape)
            # neighbor_neg_logits = torch.sum(hr_vector * nei_tail_vector, dim=1) * self.log_inv_t.exp()
            neighbor_neg_logits = hr_vector.mm(self.nei_tail_vector.t())
            # neighbor_neg_logits *= self.log_inv_t.exp()
            # print('neighbor_neg_logits--------------------------------------------------',neighbor_neg_logits.shape)
            # self_negative_mask = batch_dict['self_negative_mask']
            # self_neg_logits.masked_fill_(~self_negative_mask, -1e4)
            logits = torch.cat([logits, neighbor_neg_logits], dim=-1)


        return {'logits': logits,
                'labels': labels,
                'inv_t': self.log_inv_t.detach().exp(),
                'hr_vector': hr_vector.detach(),
                'tail_vector': tail_vector.detach()}

    def _compute_pre_batch_logits(self, hr_vector: torch.tensor,
                                  tail_vector: torch.tensor,
                                  batch_dict: dict) -> torch.tensor:
        assert tail_vector.size(0) == self.batch_size
        batch_exs = batch_dict['batch_data']
        # batch_size x num_neg
        pre_batch_logits = hr_vector.mm(self.pre_batch_vectors.clone().t())
        pre_batch_logits *= self.log_inv_t.exp() * self.args.pre_batch_weight
        if self.pre_batch_exs[-1] is not None:
            pre_triplet_mask = construct_mask(batch_exs, self.pre_batch_exs).to(hr_vector.device)
            pre_batch_logits.masked_fill_(~pre_triplet_mask, -1e4)
            # print('pre_triplet_mask--------------------------------------------------',pre_triplet_mask.shape)
        # print('pre_batch_vectors--------------------------------------------------',self.pre_batch_vectors.shape)
        # print('pre_batch_exs--------------------------------------------------',pre_batch_exs.shape)
        # print('self.offset--------------------------------------------------',self.offset)
        self.pre_batch_vectors[self.offset:(self.offset + self.batch_size)] = tail_vector.data.clone()
        self.pre_batch_exs[self.offset:(self.offset + self.batch_size)] = batch_exs
        self.offset = (self.offset + self.batch_size) % len(self.pre_batch_exs)

        return pre_batch_logits

    ##
    def pairwise_distances(self, x, y=None):
        '''
        x:64*768
        y:64*768
        Input: x is a Nxd matrix
              y is an optional Mxd matirx
        Output: dist is a NxM matrix where dist[i,j] is the square norm between x[i,:] and y[j,:]
                if y is not given then use 'y=x'.
        i.e. dist[i,j] = ||x[i,:]-y[j,:]||^2
        '''
        x_norm = (x ** 2).sum(1).view(-1, 1)  # 49152*1
        if y is not None:
            y_norm = (y ** 2).sum(1).view(1, -1)  # 1*49152
        else:
            y = x
            y_norm = x_norm.view(1, -1)  # 1*49152
        dist = x_norm + y_norm - 2.0 * torch.mm(x, torch.transpose(y, 0, 1))
        # print('dist--------------------------------------------------',dist.shape)
        return torch.clamp(dist, 0.0, np.inf)

    def _nearest_neighbor_sampling(self, tal, K):
        t = time.time()
        neg_t = []
        distance = self.pairwise_distances(tal, tal)
        for idx in range(tal.shape[0]):
            # print("idx",idx)
            _, indices = torch.sort(distance[idx, :], descending=False)
            neg_t.append(tal[indices[1: K + 1]])
        # print('neg_t--------------------------------------------------',length_hint(neg_t))
        neg_t = torch.cat(tuple(neg_t), dim=0)
        return neg_t

    ##

    @torch.no_grad()
    def predict_ent_embedding(self, tail_token_ids, tail_mask, tail_token_type_ids, **kwargs) -> dict:
        ent_vectors = self._encode(self.tail_bert,
                                   token_ids=tail_token_ids,
                                   mask=tail_mask,
                                   token_type_ids=tail_token_type_ids)
        #jd
        last_hidden_state = ent_vectors
        ent_vectors = last_hidden_state[:, 0, :]
        ent_vectors = _pool_output(self.args.pooling, ent_vectors, tail_mask, last_hidden_state)

        return {'ent_vectors': ent_vectors.detach()}


def _pool_output(pooling: str,
                 cls_output: torch.tensor,
                 mask: torch.tensor,
                 last_hidden_state: torch.tensor) -> torch.tensor:
    if pooling == 'cls':
        output_vector = cls_output
    elif pooling == 'max':
        input_mask_expanded = mask.unsqueeze(-1).expand(last_hidden_state.size()).long()
        last_hidden_state[input_mask_expanded == 0] = -1e4
        output_vector = torch.max(last_hidden_state, 1)[0]
    elif pooling == 'mean':
        input_mask_expanded = mask.unsqueeze(-1).expand(last_hidden_state.size()).float()
        sum_embeddings = torch.sum(last_hidden_state * input_mask_expanded, 1)
        sum_mask = torch.clamp(input_mask_expanded.sum(1), min=1e-4)
        output_vector = sum_embeddings / sum_mask
    else:
        assert False, 'Unknown pooling mode: {}'.format(pooling)

    output_vector = nn.functional.normalize(output_vector, dim=1)
    return output_vector
