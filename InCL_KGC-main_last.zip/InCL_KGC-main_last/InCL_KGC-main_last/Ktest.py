import matplotlib.pyplot as plt

import numpy as np
# epoch,acc,loss,val_acc,val_loss
figure, ax = plt.subplots()
figure.suptitle('WN18RR')

x_axis_data = [3, 5, 7, 9]
y_axis_data1 = [64.61, 66.83, 67.8, 65.24]
y_axis_data2 = [53.59, 56.53, 57.12, 54.59]
y_axis_data3 = [72.16, 73.98, 74.95, 72.63]
y_axis_data4 = [84.09, 84.85, 86.83, 84.51]

# 画图
plt.plot(x_axis_data, y_axis_data1, 'b*-', alpha=0.5, linewidth=1, label='MRR')
plt.plot(x_axis_data, y_axis_data2, 'rs-', alpha=0.5, linewidth=1, label='Hit@1')
plt.plot(x_axis_data, y_axis_data3, 'go-', alpha=0.5, linewidth=1, label='Hit@3')
# plt.plot(x_axis_data, y_axis_data4, 'y*-', alpha=0.5, linewidth=1, label='Hit@10')
plt.plot(x_axis_data, y_axis_data4, color='darkorange',  marker='d', alpha=0.5, linewidth=1, label='Hit@10')


## 设置数据标签位置及大小
# for a, b in zip(x_axis_data, y_axis_data1):
#     plt.text(a, b, str(b), ha='center', va='bottom', fontsize=8)  # ha='center', va='top'
# for a, b1 in zip(x_axis_data, y_axis_data2):
#     plt.text(a, b1, str(b1), ha='center', va='bottom', fontsize=8)
# for a, b2 in zip(x_axis_data, y_axis_data3):
#     plt.text(a, b2, str(b2), ha='center', va='bottom', fontsize=8)
# for a, b3 in zip(x_axis_data, y_axis_data4):
#     plt.text(a, b3, str(b3), ha='center', va='bottom', fontsize=8)


# plt.legend()  # 显示上面的label
# plt.legend(loc='upper center')
# plt.legend(loc=2)
plt.legend(loc="lower left",bbox_to_anchor=[0.3,0.7],
            ncol = 2, shadow = False, fancybox= True)




plt.grid(True, linestyle="--", alpha=0.5)
plt.xlabel('Num. of K')
plt.ylabel('MRR')  # accuracy

# plt.ylim(-1,1)#仅设置y轴坐标范围
# plt.show()
plt.savefig(fname="k_3",format="pdf")