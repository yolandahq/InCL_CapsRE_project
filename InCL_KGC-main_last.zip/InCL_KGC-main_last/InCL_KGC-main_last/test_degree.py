# import torch
#
#
# x = torch.ones(5,3)
# t = torch.tensor([[1,2,3],[4,5,6],[7,8,9]], dtype=torch.float)
# index = torch.tensor([0,4,2])
# print(x)
# print(t)
# print(index)
# x.index_add_(0,index,t)
#
# # tensor 的第 dim 维度必须与 index 的长度(必须是向量)具有相同的大小
# print(x)
# max_degree = 5
# count_degree_group = {i: 0 for i in range(0, max_degree + 1)}
# print(count_degree_group)


from functools import reduce
#
# dict = {'a': 100, 'b':200, 'c':300}
# print(reduce(lambda x,y:x+y,dict.values()))

# dict = {'a': 100, 'b':200, 'c':300}
# print(sum(dict.values()))

seen_eids = set()
seen_eids.add(5)
print(seen_eids)