import torch

from typing import List

from config import args
from triplet import EntityDict
from dict_hub import get_link_graph
from doc import Example

#add
import copy
import math

#add:rerank.py evaluate.py

def rerank_by_graph(batch_score: torch.tensor,
                    examples: List[Example],
                    entity_dict: EntityDict):

    if args.task == 'wiki5m_ind':
        assert args.neighbor_weight < 1e-6, 'Inductive setting can not use re-rank strategy'

    if args.neighbor_weight < 1e-6:
        return
    # statistics = {}
    # statistics = count_degrees(examples)
    # degrees = statistics.get("avg_degree")
    # print(degrees)
    # print("test")
    # print(statistics)
    for idx in range(batch_score.size(0)):

        cur_ex = examples[idx]

        n_hop_indices = get_link_graph().get_n_hop_entity_indices(cur_ex.head_id,
                                                                  entity_dict=entity_dict,
                                                                  n_hop=args.rerank_n_hop)

        # statistics = count_degrees(examples)
        # # print("test")
        # print(statistics)

        delta = torch.tensor([args.neighbor_weight for _ in n_hop_indices]).to(batch_score.device)

        n_hop_indices = torch.LongTensor(list(n_hop_indices)).to(batch_score.device)  # set转为张量
        # print(batch_score[idx])
        batch_score[idx].index_add_(0, n_hop_indices, delta)        #（256*135）



        # The test set of FB15k237 removes triples that are connected in train set,
        # so any two entities that are connected in train set will not appear in test,
        # however, this is not a trick that could generalize.
        # by default, we do not use this piece of code .

        # if args.task == 'FB15k237':
        #     n_hop_indices = get_link_graph().get_n_hop_entity_indices(cur_ex.head_id,
        #                                                               entity_dict=entity_dict,
        #                                                               n_hop=1)
        #     n_hop_indices.remove(entity_dict.entity_to_idx(cur_ex.head_id))
        #     delta = torch.tensor([-0.5 for _ in n_hop_indices]).to(batch_score.device)
        #     n_hop_indices = torch.LongTensor(list(n_hop_indices)).to(batch_score.device)
        #
        #     batch_score[idx].index_add_(0, n_hop_indices, delta)

# add degrees
def rerank_by_degrees(batch_score: torch.tensor,
                    examples: List[Example],
                    entity_dict: EntityDict):

    if args.task == 'wiki5m_ind':
        assert args.neighbor_weight < 1e-6, 'Inductive setting can not use re-rank strategy'

    if args.neighbor_weight < 1e-6:
        return

    for idx in range(batch_score.size(0)):

        statistics = {}
        avg_degree = 0
        degrees = {}
        statistics = count_degrees(examples)

        avg_degree = statistics.get("avg_degree")

        degrees = statistics.get("degree_group")
        # print(degrees)
        seen_eids = set()

        for k, v in degrees.items():
            if degrees[k] > avg_degree:
                # print(k)
                # print(entity_dict.entity_to_idx(k))
                seen_eids.add(entity_dict.entity_to_idx(k))
        # neighbor_weight
        delta = torch.tensor([args.neighbor_weight for _ in seen_eids]).to(batch_score.device)
        degrees_indices = torch.LongTensor(list(seen_eids)).to(batch_score.device)  # set转为张量
        batch_score[idx].index_add_(0, degrees_indices, delta)

def count_degrees(examples):
    # train_set = self.train_set  # + self.valid_set + self.test_set
    degrees = {}
    avg_degree = 0

    for example in examples:

        h= example.head_id
        # r=example.relation
        t=example.tail_id
        degrees[h] = degrees.get(h, 0) + 1
        degrees[t] = degrees.get(t, 0) + 1
        # degrees[r] = degrees.get(r, 0) + 1

    raw_degrees = copy.deepcopy(degrees)
    max_degree = 0
    for k, v in degrees.items():
        max_degree = max(max_degree, v)
    max_degree = math.floor(math.log(max_degree) / math.log(2))
    count_degree_group = {i: 0 for i in range(0, max_degree + 1)}

    for k, v in degrees.items():
        degrees[k] = math.floor(math.log(v) / math.log(2)) + 1
        count_degree_group[degrees[k]] = count_degree_group.get(degrees[k], 0) + 1

    sum= 0
    avg_degree = 0
    for k, v in degrees.items():
        sum = sum + degrees[k];
    avg_degree = sum/len(degrees)

    statistics = {
        'degrees': raw_degrees,
        'degree_group': degrees,
        'count_degree_group': count_degree_group,
        'max_degree': max_degree,
        'avg_degree': avg_degree
    }

    return statistics




