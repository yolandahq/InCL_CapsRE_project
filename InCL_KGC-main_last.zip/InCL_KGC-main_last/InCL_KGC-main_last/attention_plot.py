# ! -*- coding: utf-8 -*-
import os.path

from matplotlib import pyplot as plt
from transformers import AutoTokenizer, TFAutoModel
import numpy as np
import tensorflow as tf
import pandas as pd

# pip install seaborn -i https://pypi.tuna.tsinghua.edu.cn/simple
import seaborn as sns

# Token化工具
tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")
# BERT模型，并加载预训练权重
model = TFAutoModel.from_pretrained("bert-base-uncased")

# 数据输入 -> Token化 -> 模型输入
sentence = 'How Attention works in Deep Learning: understanding the attention mechanism in sequence models'
inputs = tokenizer(sentence, return_tensors="tf")

# 经过BERT模型，进行Attention计算
outputs = model(**inputs, output_attentions=True)