
import json

def proc_longdesc():
    # # 添加id，实体，实体描述data/UMLS/entity2textlong.txt--->entity2textlong_definitions.txt
    global val
    val = -1
    with open("data/UMLS/entity2textlong.txt", "r", encoding='utf-8') as f:
        lines = f.readlines();
    with open('data/UMLS/entity2textlong_definitions.txt', 'w', encoding='utf-8') as outfile:
        for line in lines:
            val += 1
            line = str(val) + '\t' + line
            outfile.write(line)

#entities.txt+entity2textlong_definitions.txt --->entities.json




def proc_todict():
    #  添加id: entities.txt---->entities.dict
    with open("data/UMLS/entities.txt","r") as f:
        lines = f.readlines();
        with open('data/UMLS/entities.dict', 'w') as outfile:
            for i, j in enumerate(lines):
                outfile.write("{} {}".format(i,j));


def json_nums():
    with open("data/UMLS/entities.json","r",encoding='utf-8') as f:
        lines = f.readlines();
        for i, j in enumerate(lines):
            print(i)

#json.load(open(path, 'r', encoding='utf-8'))


'''
## entities.json存在重复实体
#entity2idx [id,idx]  ---? idx值不是顺序增加    -->entities.json文件重复值导致 -->entities.json文件生成？
                    ---？length=51 
#id2entity [id,entity(id,entity,desc)] ---->train时，triplet.py报错：KeyError   ----？length=56

return self.id2entity[entity_id] #132
KeyError: '77'

'''


def main():
    proc_longdesc()


if __name__ == '__main__':
    main()