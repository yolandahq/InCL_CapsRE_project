import pandas as pd
import os
import csv

# 打开文件csv,转换一个文件
# file_path = "./data/UMLS/train.tsv"
# file_name = "tsv"
# data = pd.read_tsv(file_path, encoding='utf-8')
# with open(file_path+file_name+'.txt','a+', encoding='utf-8',) as f:
#     for line in data.values:
#         f.write((str(line[0])+'\t'+str(line[1])+'\n'))

# tsv转换成txt
def tsv_to_txt():
    tsv_file = open('E:/pythona/NevKGC_rr-main/NevKGC_rr-main/data/UMLS/dev.tsv')
    # txt_file = open('E:/pythona/NevKGC_rr-main/NevKGC_rr-main/data/UMLS/train_tsv.txt')
    # (shotname,extension) = os.path.splitext(file_name)
    read_tsv = csv.reader(tsv_file, delimiter="\t")
    # write data in txt file line by line
    with open('E:/pythona/NevKGC_rr-main/NevKGC_rr-main/data/UMLS/dev_tsv.txt','a+', encoding='utf-8',) as f:
        for row in read_tsv:
            joined_string = "\t".join(row)
            f.writelines(joined_string + '\n')

# # 添加id，实体，实体描述data/UMLS/entity2textlong.txt
# path = ''
def add_to_id():
    global val
    val = -1
    with open("data/UMLS/entity2textlong.txt", "r", encoding='utf-8') as f:
        lines = f.readlines();
    with open('data/UMLS/entity2textlong_definitions3.txt', 'w',encoding='utf-8') as outfile:
        for line in lines:
            val +=1
            line = str(val) + '\t' +line
            outfile.write(line)

def main():
    tsv_to_txt()


if __name__ == '__main__':
    main()