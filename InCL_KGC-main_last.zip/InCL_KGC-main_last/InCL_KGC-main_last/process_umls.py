import json

# 转为json，添加key
# data=[{}]
# with open('data/UMLS/train.json', 'w') as outfile, open("data/UMLS/train.tsv","r") as f:
#     firstline = f.readline()
#     columns = firstline.split()
#     lines = f.readlines()[1:]
#     for line in lines:
#         values = line.split()
#         entry = dict(zip(columns, values))
#         data.append(entry)
#     json.dump(data, outfile)



# # 添加id
# with open("data/UMLS/entities.txt","r") as f:
#     lines = f.readlines();
#     with open('data/UMLS/entities_dict1.dict', 'w') as outfile:
#         for i, j in enumerate(lines):
#             outfile.write("{} {}".format(i,j));

#
# data=[{}]
# with open('data/UMLS/train.json', 'w') as outfile, open("data/UMLS/train.tsv","r") as f:
#     firstline = f.readline()
#     columns = firstline.split()
#     lines = f.readlines()[1:]
#     for line in lines:
#         values = line.split()
#         entry = dict(zip(columns, values))
#         data.append(entry)
#     json.dump(data, outfile)

wn18rr_id2ent = {}

def _load_wn18rr_texts(path: str):
    global wn18rr_id2ent
    lines = open(path, 'r', encoding='utf-8').readlines()
    for line in lines:
        fs = line.strip().split('\t')
        assert len(fs) == 3, 'Invalid line: {}'.format(line.strip())
        entity_id, word, desc = fs[0], fs[1].replace('__', ''), fs[2]
        wn18rr_id2ent[entity_id] = (entity_id, word, desc)
    print('Load {} entities from {}'.format(len(wn18rr_id2ent), path))


def _process_line_wn18rr(line: str) -> dict:
    fs = line.strip().split('\t')
    assert len(fs) == 3, 'Expect 3 fields for {}'.format(line)
    head_id, relation, tail_id = fs[0], fs[1], fs[2]
    _, head, _ = wn18rr_id2ent[head_id]
    _, tail, _ = wn18rr_id2ent[tail_id]
    example = {'head_id': head_id,
               'head': head,
               'relation': relation,
               'tail_id': tail_id,
               'tail': tail}
    return example