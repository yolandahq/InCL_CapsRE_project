import json

data=[{}]
with open('data.json', 'w') as outfile, open("data/UMLS/train.tsv","r") as f:
    firstline = f.readline()
    columns = firstline.split()
    lines = f.readlines()[1:]
    for line in lines:
        values = line.split()
        entry = dict(zip(columns, values))
        data.append(entry)
    json.dump(data, outfile)